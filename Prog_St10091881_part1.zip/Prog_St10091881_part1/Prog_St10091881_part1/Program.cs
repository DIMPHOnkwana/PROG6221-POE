﻿using System;

namespace RecipeApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            while (true)
            {
                Console.WriteLine("Select an option:");

                Console.WriteLine("1. Enter recipe details");

                Console.WriteLine("2. Display recipe");

                Console.WriteLine("3. Scale recipe");

                Console.WriteLine("4. Reset recipe");

                Console.WriteLine("5. Clear recipe data");

                Console.WriteLine("6. Quit");

                string input = Console.ReadLine();
                Console.WriteLine();

                switch (input)
                {
                    case "1":
                        recipe.EnterRecipeDetails();
                        break;

                    case "2":
                        recipe.DisplayRecipe();
                        break;

                    case "3":
                        recipe.ScaleRecipe();
                        break;

                    case "4":
                        recipe.ResetRecipe();
                        break;

                    case "5":
                        recipe.ClearRecipeData();
                        break;

                    case "6":
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }

    class Recipe
    {
        private int numIngredients;
        private string[] ingredientNames;
        private double[] ingredientQuantities;
        private string[] ingredientUnits;
        private int numSteps;
        private string[] steps;

        public Recipe()
        {
            numIngredients = 0;
            numSteps = 0;
        }

        public void EnterRecipeDetails()
        {
            Console.Write("Enter number of ingredients: ");
            numIngredients = int.Parse(Console.ReadLine());

            ingredientNames = new string[numIngredients];
            ingredientQuantities = new double[numIngredients];
            ingredientUnits = new string[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter ingredient {i + 1} name: ");
                ingredientNames[i] = Console.ReadLine();

                Console.Write($"Enter ingredient {i + 1} quantity: ");
                ingredientQuantities[i] = double.Parse(Console.ReadLine());

                Console.Write($"Enter ingredient {i + 1} unit: ");
                ingredientUnits[i] = Console.ReadLine();
            }

            Console.Write("Enter number of steps: ");
            numSteps = int.Parse(Console.ReadLine());

            steps = new string[numSteps];

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                steps[i] = Console.ReadLine();
            }

            Console.WriteLine("Recipe details entered successfully.");
            Console.WriteLine();
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"{ingredientQuantities[i]} {ingredientUnits[i]} {ingredientNames[i]}");
            }

            Console.WriteLine();

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Step {i + 1}: {steps[i]}");
            }

            Console.WriteLine();
        }

        public void ScaleRecipe()
        {
            Console.Write("Enter scaling factor (0.5, 2, or 3): ");
            double scalingFactor = double.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                ingredientQuantities[i] *= scalingFactor;
            }

            Console.WriteLine("Recipe scaled successfully.");
            Console.WriteLine();
        }

        public void ResetRecipe()
        {
            for (int i = 0; i < numIngredients; i++)
            {
                ingredientQuantities[i] /= 2;
            }

        }

        internal void ClearRecipeData()
        {
            throw new NotImplementedException();
        }
    }
}

